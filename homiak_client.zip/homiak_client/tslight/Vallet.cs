﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using OxyPlot;
using OxyPlot.Axes;
using OxyPlot.Series;



namespace tslight
{
    public partial class Vallet : Form
    {

        static string[,] Vallets_history_data = new string[100, 4];
        DataTable  Market_depths_bid = new DataTable();
        DataTable Market_depths_ask = new DataTable();
        static int graph_length = 50;
        string[] updates = { "0", "0" };
        public static int last_ans_min = 0;
        string cur_price = "";
        public Vallet(string Vallet_input)
        {
            InitializeComponent();
            Market_depths_bid.Columns.Add("Bid", typeof(double));
            Market_depths_bid.Columns.Add("Объем", typeof(double));
            Market_depths_ask.Columns.Add("Ask", typeof(double));
            Market_depths_ask.Columns.Add("Объем", typeof(double));
            dataGridask1.DataSource = Market_depths_ask;
            dataGridbid1.DataSource = Market_depths_bid;
            for (int j = 0; j < 50; j++)
            {
                Market_depths_ask.Rows.Add(0, 0);
                Market_depths_bid.Rows.Add(0, 0);
            }
            this.Text = Vallet_input;
            Thread myThread1 = new Thread(get_data);
            myThread1.Start();

        }
        int get_t_bar_value()
        {
            //return (int)trackBar2.Invoke( new Func<int>(() => get_t_bar_value())); //trackBar2.Value;
            return (int)this.Invoke((Func<int>)delegate
            {
                return trackBar2.Value;
            });
        }
        void set_width()
        {
            dataGridask1.Columns[0].Width = 50;
            dataGridask1.Columns[1].Width = 50;
            dataGridbid1.Columns[0].Width = 50;
            dataGridbid1.Columns[1].Width = 50;
            dataGridask1.Refresh();
            dataGridbid1.Refresh();
        }
        void get_data()
        {
            
            while (true)
            {
                //try
                //{
                    for (int i = 0; i < client.Subscribed_vallets.Count; i++)
                    {
                        if (this.Text == client.Subscribed_vallets[i][0])
                        {
                            if (updates[1] != client.Subscribed_vallets[i][2])
                            {
                                if (DateTime.Now.Minute != last_ans_min)
                                {
                                    last_ans_min = DateTime.Now.Minute;
                                    client.get_history_data_seccode(this.Text, (get_t_bar_value() + 1).ToString(), 100);
                                }
                                updates[1] = client.Subscribed_vallets[i][2];
                                Vallets_history_data = client.Vallets_history_data[i];
                                cur_price = Vallets_history_data[99, 1];
                                if (dataGridask1.IsHandleCreated)
                                {
                                    if (this.InvokeRequired)
                                        this.Invoke(new MethodInvoker(draw_candles));
                                    else draw_candles();
                                }

                           
                            }
                            if (updates[0] != client.Subscribed_vallets[i][1])
                            {
                                updates[0] = client.Subscribed_vallets[i][1];
                                for (int j = 0; j < 50; j++)
                                {
                                    Market_depths_bid.Rows[j][0] = client.Market_depths[i][50 + j, 1];
                                    Market_depths_bid.Rows[j][1] = client.Market_depths[i][50 + j, 0];
                                }
                                for (int j = 0; j < 50; j++)
                                {
                                    Market_depths_ask.Rows[j][0] = -1 * client.Market_depths[i][49 - j, 1];
                                    Market_depths_ask.Rows[j][1] = client.Market_depths[i][49 - j, 0];
                                }
                                if (this.InvokeRequired)
                                    this.Invoke(new MethodInvoker(set_width));
                                else set_width();
                               
                            }
                        }
                    }
                //}
                //catch {; }
                Thread.Sleep(100);
            }
        }
        public class MinuteRec
        {
            public DateTime QTime { get; set; }
            public double L { get; set; }
            public double H { get; set; }
            public double O { get; set; }
            public double C { get; set; }
            //public MinuteRec(DateTime argument, double low, double high, double open, double close)
            //{
            //    this.QTime = argument;
           //     this.L = low;
           //     this.H = high;
           //     this.O = open;
           //     this.C = close;
           // }
        }
        PlotModel CandleStickSeries()
        {
            double c_width = 0.0006;
            string c_format = "HH:mm";
            if (trackBar2.Value == 1)
                c_width = 0.003;
            else if (trackBar2.Value == 2)
                c_width = 0.009;
            else if (trackBar2.Value == 3)
                c_width = 0.036;
            else if (trackBar2.Value == 4)
            {
                c_width = 0.864;
                c_format = "dd/MM/yyyy";
            }
            else if (trackBar2.Value == 5)
                c_width = 6.048;
            
            var pm = new PlotModel { Title = this.Text + "    " + cur_price };
            var timeSpanAxis1 = new DateTimeAxis
            {
                Position = AxisPosition.Bottom,
                IsZoomEnabled = false, 
                StringFormat = c_format, 
                MaximumPadding = 0.03, 
                MinimumPadding = 0.03,
                MajorGridlineStyle = LineStyle.Dot,
                MinorGridlineStyle = LineStyle.Dot,
                MajorGridlineColor = OxyColor.FromRgb(44, 44, 44),
                TicklineColor = OxyColor.FromRgb(82, 82, 82)
            };
            pm.Axes.Add(timeSpanAxis1);
            var linearAxis1 = new LinearAxis
            { 
                Position = AxisPosition.Right,
                IsZoomEnabled = false,
                MaximumPadding = 0.1,
                MinimumPadding = 0.03,
                MajorGridlineStyle = LineStyle.Dot,
                MinorGridlineStyle = LineStyle.Dot,
                MajorGridlineColor = OxyColor.FromRgb(44, 44, 44),
                TicklineColor = OxyColor.FromRgb(82, 82, 82)
            };
            pm.Axes.Add(linearAxis1);
            List<MinuteRec> lst = new List<MinuteRec>();
            for (int x = 0; x < graph_length; x++)
            {
                //Console.WriteLine(x);
                int pos_x = 100 - graph_length + x;
                var high1 = Convert.ToDouble(float.Parse(Vallets_history_data[pos_x, 2], System.Globalization.CultureInfo.InvariantCulture));
                var low1 = Convert.ToDouble(float.Parse(Vallets_history_data[pos_x, 3], System.Globalization.CultureInfo.InvariantCulture));
                var open1 = Convert.ToDouble(float.Parse(Vallets_history_data[pos_x, 0], System.Globalization.CultureInfo.InvariantCulture));
                var close1 = Convert.ToDouble(float.Parse(Vallets_history_data[pos_x, 1], System.Globalization.CultureInfo.InvariantCulture));
                var date = Convert.ToDateTime(Vallets_history_data[pos_x, 4]);
                lst.Add(new MinuteRec { QTime = date, O = open1, H = high1, L = low1, C = close1 });
            }
            //IEnumerable<object> e1 = new object[] { QTime = TimeSpan.Parse("06:31:00"), O = 1672.5000, H = 1673.5000, L = 1671.7500, C = 1672.7500 };
            
            var candleStickSeries = new CandleStickSeries
            {
                CandleWidth = c_width,
                Color = OxyColors.DarkGray,
                IncreasingColor = OxyColor.FromRgb(0, 197, 49),
                DecreasingColor = OxyColor.FromRgb(255, 95, 95),
                DataFieldX = "QTime",
                DataFieldHigh = "H",
                DataFieldLow = "L",
                DataFieldOpen = "O",
                DataFieldClose = "C",
                TrackerFormatString = "High: {2:0.00}\nLow: {3:0.00}\nOpen: {4:0.00}\nClose: {5:0.00}",
                ItemsSource = lst
            };
            pm.Series.Add(candleStickSeries);
            return pm;
            
        }
        void draw_candles()
        {
            var model = CandleStickSeries();
            /*if (Convert.ToInt32(balance.Text) != 0)
            {
                var s2 = new LineSeries()
                {
                    Color = OxyColors.Green,
                    MarkerType = MarkerType.Circle,
                    MarkerSize = 1,
                    MarkerStroke = OxyColors.Green,
                    MarkerFill = OxyColors.Green,
                    MarkerStrokeThickness = 1.5
                };
 
                s2.Points.Add(new DataPoint(0, price_bought));
                s2.Points.Add(new DataPoint(16, price_bought));
                model.Series.Add(s2);
            }*/
            this.plotView1.Model = model;
        }
        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }
        private void trackBar1_ValueChanged(object sender, EventArgs e)
        {
            if (trackBar1.Value < 100 && trackBar1.Value > 0)
                graph_length = trackBar1.Value;
            draw_candles();
        }

        private void trackBar2_ValueChanged(object sender, EventArgs e)
        {
            if (trackBar2.Value < 6 && trackBar2.Value >= 0)
                client.get_history_data_seccode(this.Text, (trackBar2.Value+1).ToString(), 100);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (textBox2.Text != "")
            {
               // Thread myThread1 = new Thread(client.SendMessageFromSocket);
               // myThread1.Start(client.create_reqest(this.Text, "sell"));
                client.save_deal(DateTime.Now.ToString("dd.MM.yyyy"), DateTime.Now.ToString("HH:mm:ss"), textBox2.Text/*cur_price*/, this.Text, "sell", textBox1.Text);
                client.save_pos(DateTime.Now.ToString("dd.MM.yyyy"), DateTime.Now.ToString("HH:mm:ss"), textBox2.Text/*cur_price*/, this.Text, "sell", textBox1.Text);
            }
            else if (cur_price != "")
            {
                //Thread myThread1 = new Thread(client.SendMessageFromSocket);
                //myThread1.Start(client.create_reqest(this.Text, "sell"));
                client.save_deal(DateTime.Now.ToString("dd.MM.yyyy"), DateTime.Now.ToString("HH:mm:ss"), cur_price, this.Text, "sell", textBox1.Text);
                client.save_pos(DateTime.Now.ToString("dd.MM.yyyy"), DateTime.Now.ToString("HH:mm:ss"), cur_price, this.Text, "sell", textBox1.Text);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (textBox2.Text != "")
            {
                //Thread myThread1 = new Thread(client.SendMessageFromSocket);
               // myThread1.Start(client.create_reqest(this.Text, "buy"));
                client.save_deal(DateTime.Now.ToString("dd.MM.yyyy"), DateTime.Now.ToString("HH:mm:ss"), textBox2.Text/*cur_price*/, this.Text, "buy", textBox1.Text);
                client.save_pos(DateTime.Now.ToString("dd.MM.yyyy"), DateTime.Now.ToString("HH:mm:ss"), textBox2.Text/*cur_price*/, this.Text, "buy", textBox1.Text);
            }
            else if (cur_price != "")
            {
               // Thread myThread1 = new Thread(client.SendMessageFromSocket);
               // myThread1.Start(client.create_reqest(this.Text, "buy"));
                client.save_deal(DateTime.Now.ToString("dd.MM.yyyy"), DateTime.Now.ToString("HH:mm:ss"), cur_price, this.Text, "buy", textBox1.Text);
                client.save_pos(DateTime.Now.ToString("dd.MM.yyyy"), DateTime.Now.ToString("HH:mm:ss"), cur_price, this.Text, "buy", textBox1.Text);
            }
         }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
    public class Md
    {
        public int Price { get; set; }
        public string Value { get; set; }
        public Md(int Price, string Value)
        {
            this.Price = Price;
            this.Value = Value;
        }
    }
}
