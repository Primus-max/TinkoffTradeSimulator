﻿using System;
using System.IO;
using System.Linq;
using System.Text;

namespace tslight
{
    static class log
    {


        //================================================================================


        public static void StartLogging(string path)
        {
            
        }

        public static void StopLogging()
        {

        }

    }
}
