﻿namespace tslight
{
	partial class client
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
            this.txtBoxAns = new System.Windows.Forms.RichTextBox();
            this.sendcomm = new System.Windows.Forms.Button();
            this.tab_Param = new System.Windows.Forms.TabPage();
            this.response = new System.Windows.Forms.RichTextBox();
            this.chs_Server = new System.Windows.Forms.ComboBox();
            this.checkBox_console = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Client_text = new System.Windows.Forms.TextBox();
            this.Union_text = new System.Windows.Forms.TextBox();
            this.edt_Port = new System.Windows.Forms.TextBox();
            this.edt_Login = new System.Windows.Forms.TextBox();
            this.lbl_Port = new System.Windows.Forms.Label();
            this.print = new System.Windows.Forms.RichTextBox();
            this.lbl_IP = new System.Windows.Forms.Label();
            this.lbl_Password = new System.Windows.Forms.Label();
            this.lbl_Login = new System.Windows.Forms.Label();
            this.edt_Password = new System.Windows.Forms.TextBox();
            this.Tabs = new System.Windows.Forms.TabControl();
            this.tab_Security = new System.Windows.Forms.TabPage();
            this.button2 = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.obem = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.label8 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col123 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col1234 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_Connect = new System.Windows.Forms.Label();
            this.txt_Status = new System.Windows.Forms.Label();
            this.btn_Connect = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dg_Security = new System.Windows.Forms.DataGridView();
            this.id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.code = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.open_tab = new System.Windows.Forms.DataGridViewButtonColumn();
            this.add = new System.Windows.Forms.DataGridViewButtonColumn();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.favorites = new System.Windows.Forms.DataGridView();
            this.id1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.code1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.open_tab1 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.delete_tab1 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.label7 = new System.Windows.Forms.Label();
            this.tab_Param.SuspendLayout();
            this.Tabs.SuspendLayout();
            this.tab_Security.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg_Security)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.favorites)).BeginInit();
            this.SuspendLayout();
            // 
            // txtBoxAns
            // 
            this.txtBoxAns.Location = new System.Drawing.Point(11, 32);
            this.txtBoxAns.Name = "txtBoxAns";
            this.txtBoxAns.Size = new System.Drawing.Size(328, 243);
            this.txtBoxAns.TabIndex = 26;
            this.txtBoxAns.Text = "";
            // 
            // sendcomm
            // 
            this.sendcomm.Location = new System.Drawing.Point(170, 476);
            this.sendcomm.Name = "sendcomm";
            this.sendcomm.Size = new System.Drawing.Size(169, 24);
            this.sendcomm.TabIndex = 40;
            this.sendcomm.Text = "Send Comm";
            this.sendcomm.UseVisualStyleBackColor = true;
            this.sendcomm.Click += new System.EventHandler(this.sendcomm_Click);
            // 
            // tab_Param
            // 
            this.tab_Param.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.tab_Param.Controls.Add(this.response);
            this.tab_Param.Controls.Add(this.chs_Server);
            this.tab_Param.Controls.Add(this.txtBoxAns);
            this.tab_Param.Controls.Add(this.checkBox_console);
            this.tab_Param.Controls.Add(this.label5);
            this.tab_Param.Controls.Add(this.button6);
            this.tab_Param.Controls.Add(this.label1);
            this.tab_Param.Controls.Add(this.Client_text);
            this.tab_Param.Controls.Add(this.Union_text);
            this.tab_Param.Controls.Add(this.edt_Port);
            this.tab_Param.Controls.Add(this.sendcomm);
            this.tab_Param.Controls.Add(this.edt_Login);
            this.tab_Param.Controls.Add(this.lbl_Port);
            this.tab_Param.Controls.Add(this.print);
            this.tab_Param.Controls.Add(this.lbl_IP);
            this.tab_Param.Controls.Add(this.lbl_Password);
            this.tab_Param.Controls.Add(this.lbl_Login);
            this.tab_Param.Controls.Add(this.edt_Password);
            this.tab_Param.Location = new System.Drawing.Point(4, 22);
            this.tab_Param.Name = "tab_Param";
            this.tab_Param.Padding = new System.Windows.Forms.Padding(3);
            this.tab_Param.Size = new System.Drawing.Size(884, 701);
            this.tab_Param.TabIndex = 2;
            this.tab_Param.Text = "Параметры";
            // 
            // response
            // 
            this.response.Location = new System.Drawing.Point(11, 281);
            this.response.Name = "response";
            this.response.Size = new System.Drawing.Size(328, 189);
            this.response.TabIndex = 59;
            this.response.Text = "";
            this.response.TextChanged += new System.EventHandler(this.BuySell_TextChanged);
            // 
            // chs_Server
            // 
            this.chs_Server.FormattingEnabled = true;
            this.chs_Server.Items.AddRange(new object[] {
            "АО \"Финам\"",
            "АО \"Банк Финам\"",
            "Демо"});
            this.chs_Server.Location = new System.Drawing.Point(348, 110);
            this.chs_Server.Name = "chs_Server";
            this.chs_Server.Size = new System.Drawing.Size(121, 21);
            this.chs_Server.TabIndex = 34;
            this.chs_Server.TextChanged += new System.EventHandler(this.ComboBox1_TextChanged);
            // 
            // checkBox_console
            // 
            this.checkBox_console.AutoSize = true;
            this.checkBox_console.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.checkBox_console.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBox_console.Location = new System.Drawing.Point(11, 2);
            this.checkBox_console.Name = "checkBox_console";
            this.checkBox_console.Size = new System.Drawing.Size(93, 24);
            this.checkBox_console.TabIndex = 131;
            this.checkBox_console.Text = "Console";
            this.checkBox_console.UseVisualStyleBackColor = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(345, 207);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 20);
            this.label5.TabIndex = 203;
            this.label5.Text = "Union";
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button6.Location = new System.Drawing.Point(264, 2);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 132;
            this.button6.Text = "Clean";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(345, 181);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 20);
            this.label1.TabIndex = 202;
            this.label1.Text = "Client";
            // 
            // Client_text
            // 
            this.Client_text.ForeColor = System.Drawing.SystemColors.MenuText;
            this.Client_text.Location = new System.Drawing.Point(402, 180);
            this.Client_text.Name = "Client_text";
            this.Client_text.Size = new System.Drawing.Size(96, 20);
            this.Client_text.TabIndex = 201;
            // 
            // Union_text
            // 
            this.Union_text.ForeColor = System.Drawing.SystemColors.MenuText;
            this.Union_text.Location = new System.Drawing.Point(402, 206);
            this.Union_text.Name = "Union_text";
            this.Union_text.Size = new System.Drawing.Size(96, 20);
            this.Union_text.TabIndex = 200;
            // 
            // edt_Port
            // 
            this.edt_Port.Location = new System.Drawing.Point(347, 147);
            this.edt_Port.Name = "edt_Port";
            this.edt_Port.Size = new System.Drawing.Size(122, 20);
            this.edt_Port.TabIndex = 16;
            // 
            // edt_Login
            // 
            this.edt_Login.Location = new System.Drawing.Point(345, 32);
            this.edt_Login.Name = "edt_Login";
            this.edt_Login.Size = new System.Drawing.Size(122, 20);
            this.edt_Login.TabIndex = 8;
            // 
            // lbl_Port
            // 
            this.lbl_Port.Location = new System.Drawing.Point(346, 130);
            this.lbl_Port.Name = "lbl_Port";
            this.lbl_Port.Size = new System.Drawing.Size(100, 10);
            this.lbl_Port.TabIndex = 17;
            this.lbl_Port.Text = "Порт";
            // 
            // print
            // 
            this.print.BackColor = System.Drawing.SystemColors.HighlightText;
            this.print.ForeColor = System.Drawing.SystemColors.InfoText;
            this.print.Location = new System.Drawing.Point(6, 506);
            this.print.Name = "print";
            this.print.Size = new System.Drawing.Size(333, 194);
            this.print.TabIndex = 40;
            this.print.Text = "";
            // 
            // lbl_IP
            // 
            this.lbl_IP.Location = new System.Drawing.Point(346, 91);
            this.lbl_IP.Name = "lbl_IP";
            this.lbl_IP.Size = new System.Drawing.Size(100, 10);
            this.lbl_IP.TabIndex = 13;
            this.lbl_IP.Text = "IP адрес";
            // 
            // lbl_Password
            // 
            this.lbl_Password.Location = new System.Drawing.Point(345, 53);
            this.lbl_Password.Name = "lbl_Password";
            this.lbl_Password.Size = new System.Drawing.Size(100, 10);
            this.lbl_Password.TabIndex = 11;
            this.lbl_Password.Text = "Пароль";
            // 
            // lbl_Login
            // 
            this.lbl_Login.Location = new System.Drawing.Point(345, 18);
            this.lbl_Login.Name = "lbl_Login";
            this.lbl_Login.Size = new System.Drawing.Size(100, 10);
            this.lbl_Login.TabIndex = 9;
            this.lbl_Login.Text = "Логин";
            this.lbl_Login.Click += new System.EventHandler(this.lbl_Login_Click);
            // 
            // edt_Password
            // 
            this.edt_Password.Location = new System.Drawing.Point(347, 70);
            this.edt_Password.Name = "edt_Password";
            this.edt_Password.Size = new System.Drawing.Size(122, 20);
            this.edt_Password.TabIndex = 10;
            this.edt_Password.UseSystemPasswordChar = true;
            // 
            // Tabs
            // 
            this.Tabs.Controls.Add(this.tab_Security);
            this.Tabs.Controls.Add(this.tab_Param);
            this.Tabs.Location = new System.Drawing.Point(-3, 2);
            this.Tabs.Name = "Tabs";
            this.Tabs.SelectedIndex = 0;
            this.Tabs.Size = new System.Drawing.Size(892, 727);
            this.Tabs.TabIndex = 7;
            // 
            // tab_Security
            // 
            this.tab_Security.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.tab_Security.Controls.Add(this.button2);
            this.tab_Security.Controls.Add(this.panel4);
            this.tab_Security.Controls.Add(this.panel3);
            this.tab_Security.Controls.Add(this.panel1);
            this.tab_Security.Controls.Add(this.txt_Connect);
            this.tab_Security.Controls.Add(this.txt_Status);
            this.tab_Security.Controls.Add(this.btn_Connect);
            this.tab_Security.Controls.Add(this.panel2);
            this.tab_Security.Location = new System.Drawing.Point(4, 22);
            this.tab_Security.Name = "tab_Security";
            this.tab_Security.Padding = new System.Windows.Forms.Padding(3);
            this.tab_Security.Size = new System.Drawing.Size(884, 701);
            this.tab_Security.TabIndex = 1;
            this.tab_Security.Text = "Инструменты";
            this.tab_Security.Click += new System.EventHandler(this.tab_Security_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(398, 7);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 12;
            this.button2.Text = "test";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_2);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel4.Controls.Add(this.dataGridView2);
            this.panel4.Controls.Add(this.label8);
            this.panel4.Location = new System.Drawing.Point(394, 63);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(487, 329);
            this.panel4.TabIndex = 11;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.Column8,
            this.obem,
            this.Column6,
            this.Column7});
            this.dataGridView2.Location = new System.Drawing.Point(4, 35);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.Size = new System.Drawing.Size(480, 290);
            this.dataGridView2.TabIndex = 4;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Дата";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Время";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "Инструмент";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // Column8
            // 
            this.Column8.HeaderText = "Цена";
            this.Column8.Name = "Column8";
            // 
            // obem
            // 
            this.obem.HeaderText = "Обьем";
            this.obem.Name = "obem";
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Прибыль";
            this.Column6.Name = "Column6";
            // 
            // Column7
            // 
            this.Column7.HeaderText = "";
            this.Column7.Name = "Column7";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Mongolian Baiti", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(4, 7);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(171, 23);
            this.label8.TabIndex = 5;
            this.label8.Text = "Открытые позиции";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel3.Controls.Add(this.comboBox2);
            this.panel3.Controls.Add(this.dataGridView1);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.comboBox1);
            this.panel3.Location = new System.Drawing.Point(394, 394);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(487, 307);
            this.panel3.TabIndex = 10;
            // 
            // comboBox2
            // 
            this.comboBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "сегодня",
            "3 дня",
            "неделя",
            "месяц",
            "3 месяца",
            "пол года",
            "год",
            "все время",
            " "});
            this.comboBox2.Location = new System.Drawing.Point(160, 4);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(116, 28);
            this.comboBox2.TabIndex = 7;
            this.comboBox2.Text = "сегодня";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.col123,
            this.col1234});
            this.dataGridView1.Location = new System.Drawing.Point(4, 35);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.Size = new System.Drawing.Size(480, 266);
            this.dataGridView1.TabIndex = 4;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Дата";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Время";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Инструмент";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Цена";
            this.Column4.Name = "Column4";
            // 
            // col123
            // 
            this.col123.HeaderText = "Операция";
            this.col123.Name = "col123";
            this.col123.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // col1234
            // 
            this.col1234.HeaderText = "Объем";
            this.col1234.Name = "col1234";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Mongolian Baiti", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(4, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(151, 23);
            this.label2.TabIndex = 5;
            this.label2.Text = "История Сделок";
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "покупка",
            "продажа",
            "все"});
            this.comboBox1.Location = new System.Drawing.Point(282, 4);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(116, 28);
            this.comboBox1.TabIndex = 6;
            this.comboBox1.Text = "все";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Location = new System.Drawing.Point(6, 6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(384, 54);
            this.panel1.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Mongolian Baiti", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label6.Location = new System.Drawing.Point(137, 7);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 23);
            this.label6.TabIndex = 2;
            this.label6.Text = "0,00 ₽";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Mongolian Baiti", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 7);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(128, 23);
            this.label4.TabIndex = 1;
            this.label4.Text = "100000,00 ₽";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(4, 30);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(151, 16);
            this.label3.TabIndex = 0;
            this.label3.Text = "Демо счет 🞄 Даниил";
            // 
            // txt_Connect
            // 
            this.txt_Connect.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txt_Connect.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txt_Connect.ForeColor = System.Drawing.Color.Black;
            this.txt_Connect.Location = new System.Drawing.Point(736, 3);
            this.txt_Connect.Name = "txt_Connect";
            this.txt_Connect.Size = new System.Drawing.Size(145, 54);
            this.txt_Connect.TabIndex = 3;
            this.txt_Connect.Text = "offline";
            this.txt_Connect.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txt_Status
            // 
            this.txt_Status.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.txt_Status.Location = new System.Drawing.Point(583, 33);
            this.txt_Status.Name = "txt_Status";
            this.txt_Status.Size = new System.Drawing.Size(147, 24);
            this.txt_Status.TabIndex = 1;
            this.txt_Status.Text = "...";
            this.txt_Status.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_Connect
            // 
            this.btn_Connect.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_Connect.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_Connect.Location = new System.Drawing.Point(583, 3);
            this.btn_Connect.Name = "btn_Connect";
            this.btn_Connect.Size = new System.Drawing.Size(147, 30);
            this.btn_Connect.TabIndex = 0;
            this.btn_Connect.Text = "Подключить";
            this.btn_Connect.UseVisualStyleBackColor = false;
            this.btn_Connect.Click += new System.EventHandler(this.btn_Connect_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel2.Controls.Add(this.tabControl1);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Location = new System.Drawing.Point(6, 63);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(384, 644);
            this.panel2.TabIndex = 8;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(5, 30);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(376, 604);
            this.tabControl1.TabIndex = 4;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dg_Security);
            this.tabPage1.Controls.Add(this.textBox2);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(368, 578);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Все";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dg_Security
            // 
            this.dg_Security.AllowDrop = true;
            this.dg_Security.AllowUserToAddRows = false;
            this.dg_Security.AllowUserToDeleteRows = false;
            this.dg_Security.AllowUserToResizeRows = false;
            this.dg_Security.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dg_Security.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_Security.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id,
            this.code,
            this.open_tab,
            this.add});
            this.dg_Security.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dg_Security.Location = new System.Drawing.Point(3, 38);
            this.dg_Security.MultiSelect = false;
            this.dg_Security.Name = "dg_Security";
            this.dg_Security.RowHeadersVisible = false;
            this.dg_Security.RowHeadersWidth = 20;
            this.dg_Security.RowTemplate.Height = 18;
            this.dg_Security.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dg_Security.Size = new System.Drawing.Size(362, 537);
            this.dg_Security.TabIndex = 0;
            this.dg_Security.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dg_Security_CellContentClick);
            // 
            // id
            // 
            this.id.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.id.DataPropertyName = "id";
            this.id.HeaderText = "id";
            this.id.Name = "id";
            this.id.ReadOnly = true;
            this.id.Width = 90;
            // 
            // code
            // 
            this.code.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.code.DataPropertyName = "code";
            this.code.HeaderText = "Код";
            this.code.Name = "code";
            this.code.Width = 90;
            // 
            // open_tab
            // 
            this.open_tab.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.open_tab.DataPropertyName = "open_tab";
            this.open_tab.HeaderText = "";
            this.open_tab.Name = "open_tab";
            this.open_tab.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.open_tab.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.open_tab.Width = 89;
            // 
            // add
            // 
            this.add.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.add.DataPropertyName = "add";
            this.add.HeaderText = "";
            this.add.Name = "add";
            this.add.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.add.Width = 90;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox2.Location = new System.Drawing.Point(168, 6);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(113, 26);
            this.textBox2.TabIndex = 1;
            this.textBox2.Text = "SiU3";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.Location = new System.Drawing.Point(287, 6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 26);
            this.button1.TabIndex = 2;
            this.button1.Text = "Найти";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.favorites);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(368, 578);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Избранные";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // favorites
            // 
            this.favorites.AllowDrop = true;
            this.favorites.AllowUserToAddRows = false;
            this.favorites.AllowUserToDeleteRows = false;
            this.favorites.AllowUserToResizeRows = false;
            this.favorites.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.favorites.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.favorites.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id1,
            this.code1,
            this.open_tab1,
            this.delete_tab1});
            this.favorites.Dock = System.Windows.Forms.DockStyle.Fill;
            this.favorites.Location = new System.Drawing.Point(3, 3);
            this.favorites.MultiSelect = false;
            this.favorites.Name = "favorites";
            this.favorites.RowHeadersVisible = false;
            this.favorites.RowHeadersWidth = 30;
            this.favorites.RowTemplate.Height = 18;
            this.favorites.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.favorites.Size = new System.Drawing.Size(362, 572);
            this.favorites.TabIndex = 1;
            this.favorites.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.favorites_CellContentClick);
            // 
            // id1
            // 
            this.id1.DataPropertyName = "id";
            this.id1.HeaderText = "id";
            this.id1.Name = "id1";
            // 
            // code1
            // 
            this.code1.DataPropertyName = "code";
            this.code1.HeaderText = "Код";
            this.code1.Name = "code1";
            // 
            // open_tab1
            // 
            this.open_tab1.DataPropertyName = "open_tab";
            this.open_tab1.HeaderText = "";
            this.open_tab1.Name = "open_tab1";
            this.open_tab1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.open_tab1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // delete_tab1
            // 
            this.delete_tab1.DataPropertyName = "delete_tab";
            this.delete_tab1.HeaderText = "";
            this.delete_tab1.Name = "delete_tab1";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Mongolian Baiti", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(3, 4);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(123, 23);
            this.label7.TabIndex = 3;
            this.label7.Text = "Инструменты";
            // 
            // client
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ClientSize = new System.Drawing.Size(891, 729);
            this.Controls.Add(this.Tabs);
            this.Name = "client";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Gliph Trade";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainFormFormClosing);
            this.Load += new System.EventHandler(this.MainFormLoad);
            this.tab_Param.ResumeLayout(false);
            this.tab_Param.PerformLayout();
            this.Tabs.ResumeLayout(false);
            this.tab_Security.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg_Security)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.favorites)).EndInit();
            this.ResumeLayout(false);

		}
        private System.Windows.Forms.RichTextBox txtBoxAns;
        private System.Windows.Forms.DataGridViewTextBoxColumn security_name;
        private System.Windows.Forms.Button sendcomm;
        private System.Windows.Forms.TabPage tab_Param;
        private System.Windows.Forms.ComboBox chs_Server;
        private System.Windows.Forms.TextBox edt_Port;
        private System.Windows.Forms.TextBox edt_Login;
        private System.Windows.Forms.Label lbl_Port;
        private System.Windows.Forms.Label lbl_IP;
        private System.Windows.Forms.Label lbl_Password;
        private System.Windows.Forms.TextBox edt_Password;
        private System.Windows.Forms.Label lbl_Login;
        private System.Windows.Forms.TabControl Tabs;
        private System.Windows.Forms.CheckBox checkBox_console;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox Union_text;
        private System.Windows.Forms.TextBox Client_text;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox[] Currency;
        private System.Windows.Forms.RichTextBox print;
        private System.Windows.Forms.RichTextBox response;
        private System.Windows.Forms.TabPage tab_Security;
        private System.Windows.Forms.Label txt_Connect;
        private System.Windows.Forms.Label txt_Status;
        private System.Windows.Forms.Button btn_Connect;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView dg_Security;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView favorites;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridViewTextBoxColumn id;
        private System.Windows.Forms.DataGridViewTextBoxColumn code;
        private System.Windows.Forms.DataGridViewButtonColumn open_tab;
        private System.Windows.Forms.DataGridViewButtonColumn add;
        private System.Windows.Forms.DataGridViewTextBoxColumn id1;
        private System.Windows.Forms.DataGridViewTextBoxColumn code1;
        private System.Windows.Forms.DataGridViewButtonColumn open_tab1;
        private System.Windows.Forms.DataGridViewButtonColumn delete_tab1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn col123;
        private System.Windows.Forms.DataGridViewTextBoxColumn col1234;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn obem;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewButtonColumn Column7;
    }
}
