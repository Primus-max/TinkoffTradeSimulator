﻿using System;
using System.IO;
using System.Data;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Diagnostics;
using System.Threading;
using System.Linq;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Linq;
using OxyPlot;
using OxyPlot.Axes;
using OxyPlot.Series;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;


namespace tslight
{

    

    /// Description of MainForm.
    public partial class client : Form
    {
        public static string cl_Login = "FZTC20444A";
        public static string cl_Pass = "zzzzzzzz1";

        public static string[] _Vallets_ = { "EuZ2", "SiZ2", "BRZ2", "GZZ2" };
        public string[] _prices_ = new string[_Vallets_.Length];
        public float[,,] _stakan_ = new float[_Vallets_.Length, 200, 2];
        public bool[] _subscribed_ = new bool[_Vallets_.Length];
        

        public static string[] open = new string[100];
        public static string[] close = new string[100];
        public static string[] high = new string[100];
        public static string[] low = new string[100];
        public static DateTime[] candle_time = new DateTime[100];
        public static int[] graph_length = { 80, 80, 80, 80 };
        public string AppDir; // путь к папке приложения
        public string sLogin; // логин пользователя для сервера Transaq
        public string sPassword; // пароль пользователя для сервера Transaq
        public string ServerIP; // IP адрес сервера Transaq
        public string ServerPort; // номер порта сервера Transaq
        public string Union = "";
        public string Client = "";
        public int session_timeout;
        public int request_timeout;
        public const int ar_len = 11;
        public long[] time_order = new long[8];
        public string sec = "";
        public float price_bought = 0;
        public int minute_last = 0;
        public double time = 0;
        public int first_stuck = 1;
        public int pack = 1;
        public int[] second_old = new int[8] { -1, -1, -1, -1, -1, -1, -1, -1 };
        public float[] prices = new float[8];
        public int TR = 1;
        public int F = 1;
        public int counter_timer = 1001;
        public int[] order_now = new int[8];
        public int order_num = 0;
        public float last_price = 0;
        public int[] mins = new int[8] { 1, 2, 3, 4, 6, 8, 10, 12 };
        public int[,] stakanich = new int[1000, 2];
        public float[,,] stakan = new float[8, 200, 2];
        public int[] stakan_X = new int[100];
        public int[] first = new int[8];
        public int[] delay = new int[8];
        public double suck_time = 0;
        private bool bConnected;
        private bool bConnecting;
        public int shurence = 0;
        public DataSet_tslight DTS;
        public DataTable DTS1;
        public DataTable DTS_new;
        public DataTable DTS_favorites;
        public char PointChar; // символ для замены точки в числах

        public static List<string[]> Subscribed_vallets = new List<string[]>();
        public static List<string[,]> Vallets_history_data = new List<string[,]>();
        public static List<float[,]> Market_depths = new List<float[,]>();



        private event NewStringDataHandler onNewFormDataEvent;
        private event NewStringDataHandler onNewSecurityEvent;
        private event NewStringDataHandler onNewTimeframeEvent;
        private event NewBoolDataHandler onNewStatusEvent;
        List<stocks> stocks1 = new List<stocks>();
        List<stocks> stocks2 = new List<stocks>();
        List<stocks> stocks3 = new List<stocks>();
        List<stocks> stocks4 = new List<stocks>();
        List<stocks> stocks5 = new List<stocks>();
        List<stocks> stocks6 = new List<stocks>();
        List<stocks> stocks7 = new List<stocks>();
        List<stocks> stocks8 = new List<stocks>();
        public string[] boofer = new string[3];
        public List<ComboBox> Currencies_boxes = new List<ComboBox>();
        public List<DataGridView> bids_boxes = new List<DataGridView>();
        public List<DataGridView> asks_boxes = new List<DataGridView>();
        public List<TextBox> sum_bids = new List<TextBox>();
        public List<TextBox> sum_asks = new List<TextBox>();
        public static bool data_updated = true;
        public bool close_end = true;

        //================================================================================
        public client()
        {
            InitializeComponent();
            // определение папки, в которой запущена программа
            string path = Application.ExecutablePath;
            AppDir = path.Substring(0, path.LastIndexOf('\\') + 1);

            // The InitializeComponent() call is required for Windows Forms designer support.
           

            // определение разделителя в числах на компьютере (запятая или точка)
            PointChar = ',';
            string str = (1.2).ToString();
            if (str.IndexOf('.') > 0) PointChar = '.';
            Thread myThread1 = new Thread(data_update);
            myThread1.Start();
        }
        void data_update()
        {
            while (true)
            {
                Thread.Sleep(100);
                if (!data_updated)
                {
                    if (this.InvokeRequired)
                        this.Invoke(new MethodInvoker(read_deals));
                    else read_deals();
                    if (this.InvokeRequired)
                        this.Invoke(new MethodInvoker(read_pos));
                    else read_pos();
                    data_updated = true;
                }
               
            }
        }
        //================================================================================
        void MainFormLoad(object sender, EventArgs e)
        {


            // параметры по умолчанию
            for (int k = 0; k < 8; k++)
            {
                delay[k] = 0;
                for (int i = 0; i < 200; i++)
                    for (int j = 0; j < 2; j++)
                    {
                        stakan[k, i, j] = 0;
                    }
            }
            for (int i6 = 0; i6 < high.Length; i6++) { high[i6] = ""; low[i6] = ""; close[i6] = ""; open[i6] = ""; }

            session_timeout = 25;
            request_timeout = 10;
            edt_Login.Text = cl_Login;// "FZTC11985A";
            edt_Password.Text = cl_Pass;//"ifkjcnmelfkfcm";
            chs_Server.Text = "АО \"Финам\"";
            edt_Port.Text = "3900";

            bConnected = false;
            bConnecting = false;

            Init_Data();

            TXmlConnector.statusTimeout = session_timeout * 1000;

            TXmlConnector.ConnectorSetCallback(OnNewFormData, OnNewSecurity, OnNewTimeframe, OnNewStatus);

            this.onNewFormDataEvent += new NewStringDataHandler(Add_FormData);
            this.onNewSecurityEvent += new NewStringDataHandler(Add_Security);
            this.onNewTimeframeEvent += new NewStringDataHandler(Add_Timeframe);
            this.onNewStatusEvent += new NewBoolDataHandler(ConnectionStatusReflect);

            TXmlConnector.FormReady = true;

            string LogPath = AppDir + "\0";

            TXmlConnector.ConnectorInitialize(LogPath, 1);
            TXmlConnector.statusDisconnected.Set();
            //Transaq_Connect();
            
        }

        private void OnNewFormData(string data)
        {
            this.Invoke(onNewFormDataEvent, new object[] { data });
        }
        private void OnNewSecurity(string data)
        {
            this.Invoke(onNewSecurityEvent, new object[] { data });
        }
        private void OnNewTimeframe(string data)
        {
            this.Invoke(onNewTimeframeEvent, new object[] { data });
        }
        private void OnNewStatus(bool status)
        {
            this.Invoke(onNewStatusEvent, new object[] { status });
        }

        //================================================================================
        void MainFormFormClosing(object sender, FormClosingEventArgs e)
        {
            TXmlConnector.FormReady = false;

            if (bConnected || bConnecting)
            {
                Transaq_Disconnect();
            }

            TXmlConnector.ConnectorUnInitialize();
        }

        //================================================================================
        public void ShowStatus(string status_str)
        {
            // вывод сообщения в строке статуса формы
            txt_Status.Text = status_str;
            txt_Status.Refresh();
        }

        //================================================================================
        public void Init_Data()
        {
            // создание объекта DataSet с таблицами 
            DTS = new DataSet_tslight();

            DTS_new = new DataTable();
            DTS_new.Columns.Add(new DataColumn("id", typeof(String), null, MappingType.Element));
            DTS_new.Columns.Add(new DataColumn("code", typeof(String), null, MappingType.Element));
            DTS_new.Columns.Add(new DataColumn("open_tab", typeof(String), null, MappingType.Element));
            DTS_new.Columns.Add(new DataColumn("add", typeof(String), null, MappingType.Element));
            DTS1 = new DataTable();
            DTS1.Columns.Add(new DataColumn("id", typeof(String), null, MappingType.Element));
            DTS1.Columns.Add(new DataColumn("code", typeof(String), null, MappingType.Element));
            DTS1.Columns.Add(new DataColumn("open_tab", typeof(String), null, MappingType.Element));
            DTS1.Columns.Add(new DataColumn("add", typeof(String), null, MappingType.Element));
            DTS_favorites = new DataTable();
            DTS_favorites.Columns.Add(new DataColumn("id", typeof(String), null, MappingType.Element));
            DTS_favorites.Columns.Add(new DataColumn("code", typeof(String), null, MappingType.Element));
            DTS_favorites.Columns.Add(new DataColumn("open_tab", typeof(String), null, MappingType.Element));
            DTS_favorites.Columns.Add(new DataColumn("delete_tab", typeof(String), null, MappingType.Element));

        }
        //================================================================================
        private void ComboBox1_TextChanged(object sender, EventArgs e)
        {
            switch (chs_Server.SelectedIndex)
            {
                case 0:
                    edt_Port.Text = "3900";
                    break;
                case 1:
                    edt_Port.Text = "3324";
                    break;
                case 2:
                    edt_Port.Text = "3939";
                    break;
            }
        }
        void Transaq_Connect()
        {
            // чтение параметров из формы
            switch (chs_Server.Text)
            {
                case "АО \"Финам\"":
                    ServerIP = "tr2.finam.online";
                    break;
                case "АО \"Банк Финам\"":
                    ServerIP = "tr1.finambank.ru";
                    break;
                case "Демо":
                    ServerIP = "tr1-demo5.finam.ru";
                    break;
            }
            if (chs_Server.Text != "АО \"Финам\"" && chs_Server.Text != "АО \"Банк Финам\"" && chs_Server.Text != "Демо" && chs_Server.Text != "tr1.finam.ru" && chs_Server.Text != "tr1.finambank.ru" && chs_Server.Text != "tr1-demo5.finam.ru")
            {
                ServerIP = chs_Server.Text;
            }

            sLogin = cl_Login;
            sPassword = cl_Pass;
            ServerPort = edt_Port.Text;

            // проверка наличия параметров
            if (sLogin.Length == 0)
            {
                ShowStatus("Не указан логин");
                return;
            }
            if (sPassword.Length == 0)
            {
                ShowStatus("Не указан пароль");
                return;
            }
            if (ServerIP.Length == 0)
            {
                ShowStatus("Не указан IP-адрес");
                return;
            }
            if (ServerPort.Length == 0)
            {
                ShowStatus("Не указан порт");
                return;
            }

            ConnectingReflect();
            // очистка таблиц с данными
            DTS.t_timeframe.Clear();
            DTS.t_security.Clear();
            DTS.t_candle.Clear();
            // формирование текста команды
            string cmd = "<command id=\"connect\">";
            cmd = cmd + "<login>" + sLogin + "</login>";
            cmd = cmd + "<password>" + sPassword + "</password>";
            cmd = cmd + "<host>" + ServerIP + "</host>";
            cmd = cmd + "<port>" + ServerPort + "</port>";
            cmd = cmd + "<rqdelay>100</rqdelay>";
            cmd = cmd + "<session_timeout>" + session_timeout.ToString() + "</session_timeout> ";
            cmd = cmd + "<request_timeout>" + request_timeout.ToString() + "</request_timeout>";
            cmd = cmd + "</command>";

            // отправка команды
            TXmlConnector.statusDisconnected.Reset();
            string res = TXmlConnector.ConnectorSendCommand(cmd);
            response.Text += res + "\n";
            load_favorites();
            read_deals();
            read_pos();
        }

        //================================================================================
        void Transaq_Disconnect()
        {
            // отключение коннектора от сервера Транзак


            DisconnectingReflect();

            string cmd = "<command id=\"disconnect\"/>";

            TXmlConnector.statusDisconnected.Reset();
            string res = TXmlConnector.ConnectorSendCommand(cmd);
            response.Text += res + "\n";
        }

        //================================================================================
        void Get_Transaq_History(int SecurityID, int TimeframeID, int HistoryLength, bool ResetFlag)
        {
            // запрос исторических данных для инструмента
            string cmd = "<command id=\"gethistorydata\" ";
            cmd = cmd + "secid=\"" + SecurityID.ToString() + "\" ";
            cmd = cmd + "period=\"" + TimeframeID.ToString() + "\" ";
            cmd = cmd + "count=\"" + HistoryLength.ToString() + "\" ";
            string s = "false";
            if (ResetFlag) s = "true";
            cmd = cmd + "reset=\"" + s + "\"/>";

            string res = TXmlConnector.ConnectorSendCommand(cmd);
            response.Text += res + "\n";
        }

        void ConnectingReflect()
        {
            bConnecting = true;
            txt_Connect.Text = "connecting";
            btn_Connect.Text = "Подключаю";
            btn_Connect.Refresh();
            txt_Connect.Refresh();
            ShowStatus("Подключение к серверу...");
        }

        void DisconnectingReflect()
        {
            bConnecting = false;
            txt_Connect.Text = "disconnecting";
            btn_Connect.Text = "Отключаю";
            btn_Connect.Refresh();
            txt_Connect.Refresh();
            ShowStatus("Отключение от сервера...");
        }


        //================================================================================
        void ConnectionStatusReflect(bool connected)
        {
            // отображение состояния подключения на форме

            bConnected = connected;
            bConnecting = false;

            if (connected)
            {
                dg_Security.DataSource = DTS_new;//DTS.t_security;
                dg_Security.Refresh();

                txt_Connect.Text = "online";
                btn_Connect.Text = "Отключить";
                ShowStatus("Подключение установлено");
                this.BackColor = System.Drawing.Color.DarkGray;

            }
            else
            {

                DTS.t_timeframe.Clear();
                DTS.t_security.Clear();
                DTS.t_candle.Clear();
                dg_Security.Refresh();

                txt_Connect.Text = "offline";
                btn_Connect.Text = "Подключить";
                ShowStatus("Подключение разъединено");
                this.BackColor = System.Drawing.Color.DarkRed;
            }


            btn_Connect.Refresh();
            txt_Connect.Refresh();
        }

        public static void get_history_data_seccode(string Currency_target, string period_target, int number_of_candles)
        {
            string cmd = "<command id=\"gethistorydata\">";
            cmd = cmd + "<security>";
            cmd = cmd + "<board>" + "FUT" + "</board>";
            cmd = cmd + "<seccode>" + Currency_target + "</seccode>";
            cmd = cmd + "</security>";
            cmd = cmd + "<period>" + period_target + "</period>";
            cmd = cmd + "<count>" + number_of_candles.ToString() + "</count>";
            cmd = cmd + "<reset>" + "true" + "</reset>";
            cmd = cmd + "</command>";
            string res = TXmlConnector.ConnectorSendCommand(cmd);
        }
        void subscribe_ticks_seccode(string currency_name)
        {
            if (currency_name != "")
            {
                string cmd = "<command id=\"subscribe\">";
                cmd = cmd + "<quotes>";
                cmd = cmd + "<security>";
                cmd = cmd + "<board>" + "FUT" + "</board>";
                cmd = cmd + "<seccode>" + currency_name + "</seccode>";
                cmd = cmd + "</security>";
                cmd = cmd + "</quotes>";
                cmd = cmd + "<quotations>";
                cmd = cmd + "<security>";
                cmd = cmd + "<board>" + "FUT" + "</board>";
                cmd = cmd + "<seccode>" + currency_name + "</seccode>";
                cmd = cmd + "</security>";
                cmd = cmd + "</quotations>";
                cmd = cmd + "</command>";
                string res = TXmlConnector.ConnectorSendCommand(cmd);
                response.Text += res + "\n";
            }


        }
        public void stakan_add(int Cur, float Price, float Value, bool BySe)
        {
            int k = 0;
            if (BySe == true)
                k = 1;
            else
                k = -1;
            if (Value == -1)
                k = 0;
            bool inside = false;
            for (int j = 0; j < 200; j++)
                if (Market_depths[Cur][j, 0] == Price)
                {
                    Market_depths[Cur][j, 1] = Value * k;
                    inside = true;
                }
            if (!inside)
            {
                int i = 0;
                while (Market_depths[Cur][i, 1] != 0)
                {
                    i++;
                    
                }
                Market_depths[Cur][i, 0] = Price;
                Market_depths[Cur][i, 1] = Value * k;
            }
        }
        static void QuickSort(List<float[,]> array, int left, int right, int Cur)
        {
            var i = left;
            var j = right;
            var pivot = array[Cur][left, 0];
            while (i <= j)
            {
                while (array[Cur][i, 0] > pivot)
                {
                    i++;
                }
                while (array[Cur][j, 0] < pivot)
                {
                    j--;
                }
                if (i <= j)
                {
                    var temp = array[Cur][i, 0];
                    var temp1 = array[Cur][i, 1];
                    array[Cur][i, 0] = array[Cur][j, 0];
                    array[Cur][i, 1] = array[Cur][j, 1];
                    array[Cur][j, 0] = temp;
                    array[Cur][j, 1] = temp1;
                    i++;
                    j--;
                }
            }
            if (left < j)
                QuickSort(array, left, j, Cur);
            if (i < right)
                QuickSort(array, i, right, Cur);
        }
        public void Add_FormData(string data)
        {
            if (checkBox_console.Checked)
            {
                txtBoxAns.Text = txtBoxAns.Text + DateTime.Now.ToString("HH:mm:ss.fff") + "   " + data + "\n =================================================== \n";
            }
            if (data.Contains("<quotations>") && data.Contains("<last>"))
            {
                XmlDocument doc1 = new XmlDocument();
                doc1.LoadXml(data);
                XmlElement xRoot1 = doc1.DocumentElement;
                string ans_time = "";
                foreach (XmlNode xnode in xRoot1)
                {
                    foreach (XmlNode childnode in xnode.ChildNodes)
                    {
                        if (childnode.Name == "seccode")
                        {
                            sec = childnode.InnerText;
                        }
                        if (childnode.Name == "time")
                        {
                            ans_time = childnode.InnerText;
                        }
                        if (childnode.Name == "last")
                        {
                            for (int j = 0; j < Subscribed_vallets.Count; j++)
                            {
                                if (Subscribed_vallets[j][0] == sec)
                                {
                                    //Currency1_price.Text = childnode.InnerText;
                                    //_prices_[j] = childnode.InnerText;
                                    Vallets_history_data[j][99, 1] = childnode.InnerText;
                                    Subscribed_vallets[j][2] = Convert.ToInt32(Subscribed_vallets[j][2]) > 1000 ? "0" : (Convert.ToInt32(Subscribed_vallets[j][2]) + 1).ToString();
                                }
                            }
                        }
                    }
                }
            }
            if (data.Contains("<quotes>"))
            {

                XmlDocument doc = new XmlDocument();
                doc.LoadXml(data);
                XmlElement xRoot = doc.DocumentElement;
                foreach (XmlNode xnode in xRoot)
                {
                    foreach (XmlNode childnode in xnode.ChildNodes)
                    {
                        if (childnode.Name == "seccode")
                            boofer[0] = childnode.InnerText;
                        if (childnode.Name == "price")
                            boofer[1] = childnode.InnerText;
                        if (childnode.Name == "buy")
                            for (int j = 0; j < Subscribed_vallets.Count; j++)
                                if (boofer[0] == Subscribed_vallets[j][0])
                                    stakan_add(j, float.Parse(boofer[1], System.Globalization.CultureInfo.InvariantCulture), float.Parse(childnode.InnerText), true);
                        if (childnode.Name == "sell")
                            for (int j = 0; j < Subscribed_vallets.Count; j++)
                                if (boofer[0] == Subscribed_vallets[j][0])
                                    stakan_add(j, float.Parse(boofer[1], System.Globalization.CultureInfo.InvariantCulture), float.Parse(childnode.InnerText), false);
                    }
                }



                for (int j = 0; j < Subscribed_vallets.Count; j++)
                {

                    if (data.Contains(Subscribed_vallets[j][0]))
                    {
                        int iter = 0;
                        for (int i = 0; i < 200; i++)
                        {
                            if (Market_depths[j][i, 1] != 0)
                            {
                                Market_depths[j][iter, 0] = Market_depths[j][i, 0];
                                Market_depths[j][iter, 1] = Market_depths[j][i, 1];
                                iter++;
                            }
                        }
                        QuickSort(Market_depths, 0, 199, j);
                        for (int i = 100; i < 200; i++)
                        {
                            Market_depths[j][i, 1] = 0;
                            Market_depths[j][i, 0] = 0;
                        }
                        Subscribed_vallets[j][1] = Convert.ToInt32(Subscribed_vallets[j][1]) > 1000 ? "0" : (Convert.ToInt32(Subscribed_vallets[j][1]) + 1).ToString();
                    }
                }

            }

            if (data.Contains("positions"))
            {
                string cmd = "<command id = \"get_mc_portfolio\" client=\"" + Client + "\" union=\"" + Union + "\"/>";
                string res = TXmlConnector.ConnectorSendCommand(cmd);
                response.Text += res + "\n";
                string vallet_current = "";
                XmlDocument doc1 = new XmlDocument();
                doc1.LoadXml(data);
                XmlElement xRoot = doc1.DocumentElement;
                foreach (XmlNode xnode in xRoot)
                {
                    foreach (XmlNode childnode in xnode.ChildNodes)
                    {
                        if (childnode.Name == "seccode")
                        {
                            vallet_current = childnode.InnerText;
                        }
                        if (childnode.Name == "totalnet")
                        {
                            ;
                        }
                        if (childnode.Name == "varmargin")
                        {
                            ;
                        }

                    }
                }
            }
            if (data.Contains("<trades>"))
            {
                //string cmd = "<command id =\"get_united_portfolio\" client=\"" + Client+"\" />";
                //string res = TXmlConnector.ConnectorSendCommand(cmd);
                //BuySell.Text = BuySell.Text + DateTime.Now.ToString("HH:mm:ss.fff") + "res:" + res + "\n =================================================== \n";
            }
            if (data.Contains("mc_portfolio"))
            {
                int breaker = 0;
                XmlDocument doc1 = new XmlDocument();
                doc1.LoadXml(data);
                XmlElement xRoot1 = doc1.DocumentElement;
                foreach (XmlNode xnode in xRoot1)
                {
                    foreach (XmlNode childnode in xnode.ChildNodes)
                    {
                        if (childnode.Name == "balance")
                        {
                            breaker = 1;
                            break;
                        }

                    }
                    if (breaker == 1)
                        break;
                }
            }
            if (data.Contains("forts_acc"))
            {
                XmlDocument doc = new XmlDocument();
                doc.LoadXml(data);
                XmlElement xRoot = doc.DocumentElement;
                foreach (XmlNode xnode in xRoot)
                {
                    if (xnode.Name == "union")
                    {
                        Union = xnode.InnerText;
                        Union_text.Text = Union;
                    }
                    if (xnode.Name == "forts_acc")
                    {
                        Client = xnode.InnerText;
                        Client_text.Text = Client;
                    }
                }
            }
            if (data.Contains("<candles secid"))
            {
                string Val_name = data.Split(new string[] { "seccode=\"" }, StringSplitOptions.None)[1].Split('\"')[0];
                int i2;
                int i1;
                i1 = 0;
                var splited_values = data.Split(new string[] { "<candle date=\"" }, StringSplitOptions.None);
                for (int j = 1; j < splited_values.Length; j++)
                {
                    candle_time[j - 1] = DateTime.Parse(splited_values[j].Split('\"')[0]);
                    open[j - 1] = splited_values[j].Split(new string[] { "open=\"" }, StringSplitOptions.None)[1].Split('\"')[0];
                    close[j - 1] = splited_values[j].Split(new string[] { "close=\"" }, StringSplitOptions.None)[1].Split('\"')[0];
                    high[j - 1] = splited_values[j].Split(new string[] { "high=\"" }, StringSplitOptions.None)[1].Split('\"')[0];
                    low[j - 1] = splited_values[j].Split(new string[] { "low=\"" }, StringSplitOptions.None)[1].Split('\"')[0];

                }
                for (int k = 0; k < Vallets_history_data.Count; k++)
                    if (Subscribed_vallets[k][0] == Val_name)
                    {
                        for (int l = 0; l < 100; l++)
                        {
                            Vallets_history_data[k][l, 0] = open[l];
                            Vallets_history_data[k][l, 1] = close[l];
                            Vallets_history_data[k][l, 2] = high[l];
                            Vallets_history_data[k][l, 3] = low[l];
                            Vallets_history_data[k][l, 4] = candle_time[l].ToString();
                        }
                        Subscribed_vallets[k][2] = Convert.ToInt32(Subscribed_vallets[k][2]) > 1000 ? "0" : (Convert.ToInt32(Subscribed_vallets[k][2]) + 1).ToString();
                    }
            }
        }
        //================================================================================
        public void Add_Timeframe(string data)
        {
            if (txtBoxAns.Text.Length < 1000)
                txtBoxAns.Text += data + "--------";
            // добавление записи о таймфрейме
            string[] tf = data.Split(';');
            if (tf.Length < 3) return;

            int id = int.Parse(tf[0]);
            int length = int.Parse(tf[1]);
            string name = tf[2];

            DTS.t_timeframe.Add_Row(id, length, name);
        }

        //================================================================================
        public void Add_Security(string data)
        {
            if (txtBoxAns.Text.Length < 2000)
                txtBoxAns.Text += data + "+++++++++";
            // добавление записи об инструменте
            string[] sec = data.Split(';');
            if (sec.Length < 18) return;
            int id = int.Parse(sec[0]);
            string code = sec[2];
            DTS.t_security.Add_Row(id, code);
            DataRow workRow = DTS_new.NewRow();
            object[] aValues = new object[]
            {
                id.ToString(), code, "Открыть", "В избранное"
            };
            workRow.ItemArray = aValues;
            DTS_new.Rows.Add(workRow);
        }




        //================================================================================
        void btn_Connect_Click(object sender, EventArgs e)
        {
            if (bConnected || bConnecting)
            {
                Transaq_Disconnect();
            }
            else
            {
                if (!bConnecting) Transaq_Connect();
            }

        }

        private void lbl_Login_Click(object sender, EventArgs e)
        {

        }

        private void ticks_Click(object sender, EventArgs e)
        {
            string cmd = "<command id = \"get_securities\" />";
            string res = TXmlConnector.ConnectorSendCommand(cmd);
            response.Text += res + "\n";
        }
        private void sendcomm_Click(object sender, EventArgs e)
        {
            string cmd = print.Text;
            string res = TXmlConnector.ConnectorSendCommand(cmd);
            response.Text += res + "\n";
            //txtBoxAns.Text = cmd + "\n";
            this.response.Text += this.response.Text + res;
        }




        private void refresh_Click(object sender, EventArgs e)
        {
            string cmd = "<command id =\"get_united_portfolio\" client=\"766642g\" union=\"458295R4OKY\"/>";
            string res = TXmlConnector.ConnectorSendCommand(cmd);
            response.Text += res + "\n";

        }
        void unsubscribe_ticks_seccode(string currency_name)
        {
            if (currency_name != "")
            {
                string cmd = "<command id=\"unsubscribe\">";
                cmd = cmd + "<quotes>";
                cmd = cmd + "<security>";
                cmd = cmd + "<board>" + "FUT" + "</board>";
                cmd = cmd + "<seccode>" + currency_name + "</seccode>";
                cmd = cmd + "</security>";
                cmd = cmd + "</quotes>";

                cmd = cmd + "<quotations>";
                cmd = cmd + "<security>";
                cmd = cmd + "<board>" + "FUT" + "</board>";
                cmd = cmd + "<seccode>" + currency_name + "</seccode>";
                cmd = cmd + "</security>";
                cmd = cmd + "</quotations>";

                cmd = cmd + "</command>";
                txtBoxAns.Text = txtBoxAns.Text + cmd;
                string res = TXmlConnector.ConnectorSendCommand(cmd);
                response.Text += res + "\n";
            }

            //txtBoxAns.Text = txtBoxAns.Text + res;

        }
        private void Un_Click(object sender, EventArgs e)
        {
            ;
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string writePath = @"C:\Users\Asus\Desktop\transaq_robot\input.txt";

            //string text = dSIM0.Text + "\n" + dBRM0.Text + "\n" + dRIM0.Text + "\n" + dEu0.Text + "\n" + dGOLD0.Text + "\n" + dGAZ0.Text +"\n";
            using (StreamWriter sw = new StreamWriter(writePath, false, System.Text.Encoding.Default))
            {
                //sw.Write(text);
            }

            string path = @"C:\Users\Asus\Desktop\transaq_robot\output.txt";
            long length_old = new System.IO.FileInfo(path).Length;
            long length;
            while (true)
            {
                length = new System.IO.FileInfo(path).Length;
                if (length != length_old)
                    break;
                length_old = length;
            }


            string text1 = "";
            using (StreamWriter sw = new StreamWriter(path, false, System.Text.Encoding.Default))
            {
                sw.Write(text1);
                sw.Close();
            }



        }

        private void dg_Security_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            var senderGrid = (DataGridView)sender;
            if (senderGrid.Columns[e.ColumnIndex] is DataGridViewButtonColumn && e.RowIndex < dg_Security.Rows.Count)
            {
                if (senderGrid.Columns[e.ColumnIndex].Name == "open_tab")
                {
                    string value_of_cell = senderGrid.Rows[e.RowIndex].Cells["code"].Value.ToString();
                    bool is_inside = false;
                    for (int i = 0; i < Subscribed_vallets.Count; i++)
                        if (value_of_cell == Subscribed_vallets[i][0])
                            is_inside = true;
                    if (!is_inside)
                    {
                        string[] content = { value_of_cell, "0", "0" };
                        string[,] content1 = new string[100, 5];
                        float[,] content2 = new float[200, 2];
                        Subscribed_vallets.Add(content);
                        Vallets_history_data.Add(content1);
                        Market_depths.Add(content2);
                        subscribe_ticks_seccode(value_of_cell);
                        get_history_data_seccode(value_of_cell, "1", 100);
                    }
                    Vallet newForm = new Vallet(value_of_cell);
                    newForm.Show();
                }
                if (senderGrid.Columns[e.ColumnIndex].Name == "add")
                {
                    save_favorites(senderGrid.Rows[e.RowIndex].Cells[0].Value.ToString(), senderGrid.Rows[e.RowIndex].Cells[1].Value.ToString());
                    load_favorites();
                    /*List<string> values = new List<string>();
                    for (int i = 0; i < senderGrid.Rows[e.RowIndex].Cells.Count - 1; i++)
                        values.Add(senderGrid.Rows[e.RowIndex].Cells[i].Value.ToString());
                    values.Add("Удалить");
                    DataRow workRow = DTS_favorites.NewRow();
                    workRow.ItemArray = values.ToArray();
                    DTS_favorites.Rows.Add(workRow);
                    favorites.DataSource = DTS_favorites;
                    favorites.Refresh();*/
                }
            }

        }
        void delete_favorites(string id)
        {
            string c_file = "user_data\\favorites.txt";
            string str = File.ReadAllText(c_file);
            List<string> counter_array = new List<string>(str.Split(','));
            bool fav_found = false;
            for (int j = 0; j < counter_array.Count; j++)
            {
                var it2 = counter_array[j].Split(';');
                if (it2[0] == id)
                {
                    fav_found = true;
                    counter_array.RemoveAt(j);
                }
            }
            string output_file = "";
            for (int j = 0; j < counter_array.Count; j++)
            {
                if (counter_array[j].Length > 2)
                {
                    if (j == counter_array.Count - 1)
                        output_file += counter_array[j];
                    else
                        output_file += counter_array[j] + ",";
                }
            }
            File.WriteAllText(c_file, output_file);
        }
        void load_favorites()
        {
            DTS_favorites.Rows.Clear();
            string c_file = "user_data\\favorites.txt";
            string str = File.ReadAllText(c_file);
            List<string> counter_array = new List<string>(str.Split(','));
            if (counter_array[0].Length > 0)
            {
                for (int j = 0; j < counter_array.Count; j++)
                {
                    var it2 = counter_array[j].Split(';');
                    List<string> values = new List<string>();
                    values.Add(it2[0]);
                    values.Add(it2[1]);
                    values.Add("Открыть");
                    values.Add("Удалить");
                    DataRow workRow = DTS_favorites.NewRow();
                    workRow.ItemArray = values.ToArray();
                    DTS_favorites.Rows.Add(workRow);
                    favorites.DataSource = DTS_favorites;
                    favorites.Refresh();
                }
            }
        }
        void save_favorites(string id, string code)
        {
            string c_file = "user_data\\favorites.txt";
            if (!File.Exists(c_file))
            {
                using (StreamWriter sw = File.CreateText(c_file))
                {
                    ;
                }
            }
            string str = File.ReadAllText(c_file);
            bool fav_found = false;
            List<string> counter_array = new List<string>(str.Split(','));
            for (int j = 0; j < counter_array.Count; j++)
            {
                var it2 = counter_array[j].Split(';');
                if (it2[1] == code)
                {
                    fav_found = true;
                    counter_array[j] = id + ";" + code;
                }
            }
            if (!fav_found)
            {
                string additional_part = id + ";" + code;
                counter_array.Add(additional_part);
            }
            string output_file = "";
            for (int j = 0; j < counter_array.Count; j++)
            {
                if (counter_array[j].Length > 2)
                {
                    if (j == counter_array.Count - 1)
                        output_file += counter_array[j];
                    else
                        output_file += counter_array[j] + ",";
                }
            }
            File.WriteAllText(c_file, output_file);
        }
        string while_read_file(string path)
        {
            string str = "";
            try
            {
                str = File.ReadAllText(path);
                
            }
            catch 
            {
                while_read_file(path);
            }
            return str;
        }
        public void read_deals()
        {

            string c_file = "user_data\\deals.txt";
            string str = while_read_file(c_file);
            List<string> counter_array = new List<string>(str.Split('\n'));
            if (counter_array[0].Length > 0)
            {
                for (int j = counter_array.Count - 1; j >= 0; j--)
                {
                    var it2 = counter_array[j].Split(';');
                    if ((counter_array.Count - 1) - j < dataGridView1.Rows.Count)
                    {
                       // this.BeginInvoke((Action)(() =>
                       // {
                            this.dataGridView1.Rows[(counter_array.Count - 1) - j].Cells[0].Value = it2[0];
                            this.dataGridView1.Rows[(counter_array.Count - 1) - j].Cells[1].Value = it2[1];
                            this.dataGridView1.Rows[(counter_array.Count - 1) - j].Cells[2].Value = it2[2];
                            this.dataGridView1.Rows[(counter_array.Count - 1) - j].Cells[3].Value = it2[3];
                            this.dataGridView1.Rows[(counter_array.Count - 1) - j].Cells[4].Value = it2[4];
                            this.dataGridView1.Rows[(counter_array.Count - 1) - j].Cells[5].Value = it2[5];
                      //  }));
                    }
                    else
                    {
                       // this.BeginInvoke((Action)(() =>
                       // {
                            dataGridView1.Rows.Add(it2[0], it2[1], it2[2], it2[3], it2[4], it2[5]);
                       // }));
                    }
                    if (it2[4] == "buy")
                    {
                      //  this.BeginInvoke((Action)(() =>
                      //  {
                            dataGridView1.Rows[(counter_array.Count - 1) - j].DefaultCellStyle.BackColor = Color.FromArgb(92, 178, 149);
//}));
                    }
                    else
                    {
                      //  this.BeginInvoke((Action)(() =>
                      //  {
                            dataGridView1.Rows[(counter_array.Count - 1) - j].DefaultCellStyle.BackColor = Color.FromArgb(223, 94, 95);
                       // }));
                    }
                }
            }
        }
        public void read_pos()
        {
            string c_file = "user_data\\positions.txt";
            string str = File.ReadAllText(c_file);
            List<string> counter_array = new List<string>(str.Split('\n'));
            if (counter_array[0].Length > 0)
            {
                for (int j = counter_array.Count - 1; j >= 0; j--)
                {
                    var it2 = counter_array[j].Split(';');
                    if ((counter_array.Count - 1) - j < dataGridView2.Rows.Count)
                    {
                        dataGridView2.Rows[(counter_array.Count - 1) - j].Cells[0].Value = it2[0];
                        dataGridView2.Rows[(counter_array.Count - 1) - j].Cells[1].Value = it2[1];
                        dataGridView2.Rows[(counter_array.Count - 1) - j].Cells[2].Value = it2[2];
                        dataGridView2.Rows[(counter_array.Count - 1) - j].Cells[3].Value = it2[3];
                        dataGridView2.Rows[(counter_array.Count - 1) - j].Cells[4].Value = it2[4];
                        dataGridView2.Rows[(counter_array.Count - 1) - j].Cells[6].Value = "закрыть";
                    }
                    else
                        dataGridView2.Rows.Add(it2[0], it2[1], it2[2], it2[3], it2[4],"" ,"закрыть");
                    if (Convert.ToDouble(it2[4]) > 0)
                        dataGridView2.Rows[(counter_array.Count - 1) - j].DefaultCellStyle.BackColor = Color.FromArgb(92, 178, 149);
                    else
                        dataGridView2.Rows[(counter_array.Count - 1) - j].DefaultCellStyle.BackColor = Color.FromArgb(223, 94, 95);
                }
                for (int dgi = dataGridView2.Rows.Count - 1; dgi >= counter_array.Count; dgi--)
                    dataGridView2.Rows.RemoveAt(dgi);
            }
            else
                dataGridView2.Rows.Clear();
        }
        public static void save_pos(string deal_date, string deal_time, string deal_price, string instrument, string action, string value)
        {
            string c_file = "user_data\\positions.txt";
            if (!File.Exists(c_file))
            {
                using (StreamWriter sw = File.CreateText(c_file))
                {
                    ;
                }
            }
            string str = File.ReadAllText(c_file);
            List<string> counter_array = new List<string>(str.Split('\n'));
            string additional_part = "";
            string output_file = "";
            bool founded = false;
            for (int j = 0; j < counter_array.Count; j++)
            {
                if (counter_array[j].Length > 2)
                {
                    if (counter_array[j].Split(';')[2] == instrument)
                    {
                        string deal_date_now = counter_array[j].Split(';')[0];
                        string deal_time_now = counter_array[j].Split(';')[1];
                        string deal_price_now = counter_array[j].Split(';')[3];
                        string instrument_now = counter_array[j].Split(';')[2];
                        string value_now = counter_array[j].Split(';')[4];
                        string updated_value = "";
                        founded = true;
                        if (Math.Abs(Convert.ToDouble(value)) > Math.Abs(Convert.ToDouble(value_now)) && ((action == "buy" && Convert.ToDouble(value_now) > 0) || (action == "sell" && Convert.ToDouble(value_now) < 0)))
                        {
                            save_pos(deal_date, deal_time, deal_price, instrument, action, value_now);
                            save_pos(deal_date, deal_time, deal_price, instrument, action, (Convert.ToDouble(value) - Convert.ToDouble(value_now)).ToString());
                        }
                        else
                        {
                            
                            if (action == "buy")
                                updated_value = (Convert.ToDouble(value_now) + Convert.ToDouble(value)).ToString();
                            else
                                updated_value = (Convert.ToDouble(value_now) - Convert.ToDouble(value)).ToString();
                            if ((action == "buy" && Convert.ToDouble(updated_value) > 0) || (action == "sell" && Convert.ToDouble(updated_value) < 0))
                                deal_price_now = ((Convert.ToDouble(deal_price_now) * Math.Abs(Convert.ToDouble(value_now)) + (Convert.ToInt32(deal_price) * Math.Abs(Convert.ToInt32(value)))) / Math.Abs(Convert.ToDouble(updated_value))).ToString();

                            additional_part = deal_date_now + ";" + deal_time_now + ";" + instrument + ";" + deal_price_now + ";" + updated_value;
                            counter_array[j] = additional_part;
                        }
                    }
                }
            }
            if (!founded)
            {
                if (action == "buy")
                    additional_part = deal_date + ";" + deal_time + ";" + instrument + ";" + deal_price + ";" + value;
                else
                    additional_part = deal_date + ";" + deal_time + ";" + instrument  + ";" + deal_price + ";" + "-"+value;
                counter_array.Add(additional_part);
            }
            bool start = true;
            for (int j = 0; j < counter_array.Count; j++)
            {
                if (counter_array[j].Length > 2)
                {
                    if (counter_array[j].Split(';')[4] != "0")
                    {
                        if (start)
                        {
                            output_file += counter_array[j];
                            start = false;
                        }
                        else
                            output_file += "\n" + counter_array[j];
                    }
                }
            }
            File.WriteAllText(c_file, output_file);
            data_updated = false;
        }
        public static void save_deal(string deal_date, string deal_time, string deal_price, string instrument, string action, string value)
        {
            
            string c_file = "user_data\\deals.txt";
            if (!File.Exists(c_file))
            {
                using (StreamWriter sw = File.CreateText(c_file))
                {
                    ;
                }
            }
            string str = File.ReadAllText(c_file);
            List<string> counter_array = new List<string>(str.Split('\n'));
            string additional_part = deal_date + ";" + deal_time + ";" + instrument + ";" + deal_price + ";" + action + ";" + value;
            counter_array.Add(additional_part);
            string output_file = "";
            for (int j = 0; j < counter_array.Count; j++)
            {
                if (counter_array[j].Length > 2)
                {
                    if (j == counter_array.Count - 1)
                        output_file += counter_array[j];
                    else
                        output_file += counter_array[j] + "\n";
                }
            }
            File.WriteAllText(c_file, output_file);
            data_updated = false;
        }
        
        private void button5_Click(object sender, EventArgs e)
        {
            string cmd = "<command id =\"get_united_go\" union=\"" + Union + "\" />";
            string res = TXmlConnector.ConnectorSendCommand(cmd);
            response.Text += res + "\n";
            this.response.Text = this.response.Text + DateTime.Now.ToString("HH:mm:ss.fff") + "res:" + res + "\n =================================================== \n";
            /*int j = 0;
            while (stakanich[j, 1] < 0)
                j++;
            for (int i = 0; i < stakan_X.Length; i++)
            {
                stakan_X[i] = stakanich[j - 50 + i, 1];
            }
            //BuySell.Text = "";
            for (int i = 0; i < stakan_X.Length; i++)
            {
                BuySell.Text = BuySell.Text + stakan_X[i] + " ";
            }


            string writePath = @"C:\Users\Asus\Desktop\transaq_robot\input.txt";
            //int[] stakan_test = { 130, 543, 22, 36, 55, 36, 86, 81, 27, 28, 114, 521, 25, 168, 78, 177, 72, 78, 25, 16, 101, 1149, 199, 151, 957, 442, 163, 1335, 457, 172, 28, 158, 1640, 32, 164, 1300, 191, 153, 257, 193, 34, 163, 54, 36, 64, 23, 23, 20, 15, 5, 288, 8, 2, 11, 24, 116, 79, 99, 89, 92, 145, 248, 771, 225, 172, 112, 176, 1225, 248, 371, 345, 1321, 167, 489, 189, 389, 349, 242, 201, 808, 193, 145, 1190, 258, 108, 119, 32, 55, 79, 113, 104, 84, 164, 47, 16, 35, 26, 34, 52, 3};
            string text = "" + stakan_X[0];
            for (int i = 1; i < stakan_X.Length; i++)
            {
                text = text + "," + stakan_X[i];
            }
            using (StreamWriter sw = new StreamWriter(writePath, false, System.Text.Encoding.Default))
            {
                sw.Write(text);
            }

            string path = @"C:\Users\Asus\Desktop\transaq_robot\output.txt";
            long length_old = new System.IO.FileInfo(path).Length;
            long length;
            while (true)
            {
                length = new System.IO.FileInfo(path).Length;
                if (length != length_old)
                    break;
                length_old = length;
            }
            string[] strArray;
            using (StreamReader sr = new StreamReader(path))
            {
                string str;
                str = sr.ReadLine();
                strArray = str.Split(',');
            }

            string text1 = "";
            using (StreamWriter sw = new StreamWriter(path, false, System.Text.Encoding.Default))
            {
                sw.Write(text1);
                sw.Close();
            }

            double v1 = Convert.ToDouble(strArray[0]) / 100;
            double v3 = Convert.ToDouble(strArray[1]) / 100;
            double v2 = (1 - v1) - v3;
            draw_prediction(v1, v2, v3);*/
        }

        private void cur1_TextChanged(object sender, EventArgs e)
        {

        }
        private void BuySell_TextChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            txtBoxAns.Text = "";
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
       
        }


        private void comboBox1_TextChanged_1(object sender, EventArgs e)
        {
            for (int h = 0; h < Currencies_boxes.Count; h++)
            {
                if (_Vallets_.Contains(Currencies_boxes[h].Text))
                {
                    for (int i = 0; i < _Vallets_.Length; i++)
                        if (_Vallets_[i] == Currencies_boxes[h].Text && _subscribed_[i] == false)
                        {
                            subscribe_ticks_seccode(Currencies_boxes[h].Text);
                            get_history_data_seccode(Currencies_boxes[h].Text, "1", 100);
                        }
                    for (int i = 0; i < _Vallets_.Length; i++)
                        if (_Vallets_[i] == Currencies_boxes[h].Text)
                            _subscribed_[i] = true;

                    for (int i = 0; i < _Vallets_.Length; i++)
                    {
                        int same = 0;
                        for (int j = 0; j < Currencies_boxes.Count; j++)
                            if (_Vallets_[i] != Currencies_boxes[j].Text && _subscribed_[i] == true)
                                same++;
                        if (same == Currencies_boxes.Count)
                        {
                            unsubscribe_ticks_seccode(_Vallets_[i]);
                            _subscribed_[i] = false;
                        }
                    }
                }
                //for (int i = 0; i < _Vallets_.Length; i++)
                //    print.Text += _subscribed_[i] + " ";
            }
        }


        static public string create_reqest(string cur, string act)
        {
            return "\"Date\"" + DateTime.Now.ToString("HH:mm:ss.fff") + "\"User_id\"" + cl_Login;
        }
        private void button5_Click_1(object sender, EventArgs e)
        {
            //Thread myThread1 = new Thread(SendMessageFromSocket);
            //myThread1.Start(create_reqest(cur1.Text, "buy"));
        }

        private void button7_Click(object sender, EventArgs e)
        {
            //Thread myThread1 = new Thread(SendMessageFromSocket);
            //myThread1.Start(create_reqest(cur1.Text, "sell"));
        }
        static public void SendMessageFromSocket(object message)
        {

            byte[] bytes = new byte[1024];
            try
            {
                IPHostEntry ipHost = Dns.GetHostEntry("194.146.242.105");
                IPAddress ipAddr = ipHost.AddressList[0];
                IPEndPoint ipEndPoint = new IPEndPoint(ipAddr, 80);

                Socket sender = new Socket(ipAddr.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

                try
                {
                    sender.Connect(ipEndPoint);
                    byte[] msg = Encoding.UTF8.GetBytes(message.ToString());
                    int bytesSent = sender.Send(msg);
                    int bytesRec = sender.Receive(bytes);
                    sender.Shutdown(SocketShutdown.Both);
                    sender.Close();
                }
                catch (ArgumentNullException ane)
                {
                    Console.WriteLine("ArgumentNullException : {0}", ane.ToString());
                }
                catch (SocketException se)
                {
                    Console.WriteLine("SocketException : {0}", se.ToString());
                }
                catch (Exception e)
                {
                    Console.WriteLine("Unexpected exception : {0}", e.ToString());
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            DTS1.Clear();
            for (int i = 0; i < DTS_new.Rows.Count; i++)
                if (DTS_new.Rows[i][1].ToString().Contains(textBox2.Text))
                {
                    DTS1.Rows.Add(Convert.ToInt32(DTS_new.Rows[i][0].ToString()), DTS_new.Rows[i][1].ToString(), DTS_new.Rows[i][2].ToString(), DTS_new.Rows[i][3].ToString());
                }
            dg_Security.DataSource = DTS1;
            dg_Security.Refresh();
        }

        private void debug_TextChanged(object sender, EventArgs e)
        {

        }

        private void tab_Security_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            for (int i = 0; i < dg_Security.Columns.Count; i++)
                print.Text += dg_Security.Columns[i].Name + "   ";
        }

        private void favorites_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            var senderGrid = (DataGridView)sender;
            if (senderGrid.Columns[e.ColumnIndex] is DataGridViewButtonColumn && e.RowIndex < favorites.Rows.Count)
            {
                if (senderGrid.Columns[e.ColumnIndex].Name == "open_tab1")
                {
                    string value_of_cell = senderGrid.Rows[e.RowIndex].Cells["code1"].Value.ToString();
                    bool is_inside = false;
                    for (int i = 0; i < Subscribed_vallets.Count; i++)
                        if (value_of_cell == Subscribed_vallets[i][0])
                            is_inside = true;
                    if (!is_inside)
                    {
                        string[] content = { value_of_cell, "0", "0" };
                        string[,] content1 = new string[100, 5];
                        float[,] content2 = new float[200, 2];
                        Subscribed_vallets.Add(content);
                        Vallets_history_data.Add(content1);
                        Market_depths.Add(content2);
                        subscribe_ticks_seccode(value_of_cell);
                        get_history_data_seccode(value_of_cell, "1", 100);
                    }
                    Vallet newForm = new Vallet(value_of_cell);
                    newForm.Show();
                }
                if (senderGrid.Columns[e.ColumnIndex].Name == "delete_tab1")
                {
                    //favorites.Rows.RemoveAt(e.RowIndex);
                    delete_favorites(senderGrid.Rows[e.RowIndex].Cells[0].Value.ToString());
                    load_favorites();
                }
            }
        }

        private void button2_Click_2(object sender, EventArgs e)
        {
            read_deals();
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            var senderGrid = (DataGridView)sender;

            if (senderGrid.Columns[e.ColumnIndex] is DataGridViewButtonColumn && e.RowIndex < dataGridView2.Rows.Count)
            {
                if (close_end)
                {
                    close_end = false;
                    //Thread myThread1 = new Thread(client.SendMessageFromSocket);
                    string cur_price = "";
                    for (int j = 0; j < Subscribed_vallets.Count; j++)
                    {
                        if (Subscribed_vallets[j][0] == dataGridView2.Rows[e.RowIndex].Cells[2].Value.ToString())
                        {
                            cur_price = Vallets_history_data[j][99, 1];
                        }
                    }
                    if (dataGridView2.Rows[e.RowIndex].Cells["obem"].Value.ToString().Contains("-"))
                    {
                        //myThread1.Start(client.create_reqest(dataGridView2.Rows[e.RowIndex].Cells[2].Value.ToString(), "buy"));
                        save_deal(DateTime.Now.ToString("dd.MM.yyyy"), DateTime.Now.ToString("HH:mm:ss"), cur_price, dataGridView2.Rows[e.RowIndex].Cells[2].Value.ToString(), "buy", Math.Abs(Convert.ToInt32(dataGridView2.Rows[e.RowIndex].Cells[4].Value.ToString())).ToString());
                        save_pos(DateTime.Now.ToString("dd.MM.yyyy"), DateTime.Now.ToString("HH:mm:ss"), cur_price, dataGridView2.Rows[e.RowIndex].Cells[2].Value.ToString(), "buy", Math.Abs(Convert.ToInt32(dataGridView2.Rows[e.RowIndex].Cells[4].Value.ToString())).ToString());
                    }
                    else
                    {
                        //myThread1.Start(client.create_reqest(dataGridView2.Rows[e.RowIndex].Cells[2].Value.ToString(), "sell"));
                        save_deal(DateTime.Now.ToString("dd.MM.yyyy"), DateTime.Now.ToString("HH:mm:ss"), cur_price, dataGridView2.Rows[e.RowIndex].Cells[2].Value.ToString(), "sell", Math.Abs(Convert.ToInt32(dataGridView2.Rows[e.RowIndex].Cells[4].Value.ToString())).ToString());
                        save_pos(DateTime.Now.ToString("dd.MM.yyyy"), DateTime.Now.ToString("HH:mm:ss"), cur_price, dataGridView2.Rows[e.RowIndex].Cells[2].Value.ToString(), "sell", Math.Abs(Convert.ToInt32(dataGridView2.Rows[e.RowIndex].Cells[4].Value.ToString())).ToString());
                    }
                    close_end = true;
                }
            }
        }
    }
    class stocks : IComparable<stocks>
    {
        public string Name { get; set; }

        public float Price { get; set; }
        public string Value { get; set; }
        public int CompareTo(stocks comparePart)
        {
            // A null value means that this object is greater.
            if (comparePart == null)
                return 1;

            else
                return this.Price.CompareTo(comparePart.Price);
        }
    }
}